# Chrome-Extension_Productivity-Manager
This is a Productivity Managament Chrome Extension build under the Coding Club IITG. It's built using the following application and languages:  

1.Front-End: JavaScript , HTML and CSS. 

2.Database: Chrome(using its local storage API).

It contains the following features:

1.TIMER

2.TODO LIST

3.ALARM

4.URL BLOCKING
