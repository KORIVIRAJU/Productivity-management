console.log("chrome extension go");
// console.log("background is running");

var x = document.querySelectorAll("p");
 for (i = 0; i < x.length; i++) {
   x[i].style.backgroundColor = "yellow";
 }



// var y=document.querySelectorAll("img");
// for (i = 0; i < y.length; i++) {
// y[i].src = "https://www.nettv4u.com/imagine/b/r/a/h/m/a/brahmanandam.jpg";
// }
